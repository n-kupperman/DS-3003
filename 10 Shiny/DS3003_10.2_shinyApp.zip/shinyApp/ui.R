library(shiny)
library(shinythemes)

ui <- navbarPage("navbarPage Example",
                 theme = shinytheme("journal"),                    
                 tabPanel("IRIS data",
                          sidebarLayout(
                            sidebarPanel( 
                              sliderInput("span_adj", label = "Span adjustment:",
                                          min = 0.2, max = 0.9, value = 0.5, step = 0.1),
                            ),
                            mainPanel(tabsetPanel(
                              tabPanel("Scatterplot", plotOutput("irisplot")),
                              tabPanel("Span Value", textOutput("span_val")),
                              tabPanel("Data", dataTableOutput("data_table")),
                              tabPanel("Variable Summary", verbatimTextOutput("summary_var")))
                            ))),
                 navbarMenu("SCS data",  
                            tabPanel("Blue Line",
                                     sidebarLayout(
                                       sidebarPanel(   
                                         sliderInput("span", label = "Span adjustment:",
                                                     min = 0.2, max = 0.9, value = 0.5, step = 0.1),
                                         sliderInput("sd", label = "Standard deviation of error:",
                                                     min = 0.2, max = 2, value = 0.5, step = 0.2)  
                                       ),
                                       mainPanel(
                                         plotOutput("scsplot")
                                       )
                                     )),
                            tabPanel("Red Line",
                                     sidebarLayout(
                                       sidebarPanel(   
                                         sliderInput("span2", label = "Span adjustment:",
                                                     min = 0.2, max = 0.9, value = 0.5, step = 0.1),
                                         sliderInput("sd2", label = "Standard deviation of error:",
                                                     min = 0.2, max = 2, value = 0.5, step = 0.2)  
                                       ),
                                       mainPanel(
                                         plotOutput("scsplot2")
                                       )
                                     ))
                 ), collapsible = TRUE
)