library(ggplot2)
library(foreign)
scs <- read.spss('SCS_QE.sav', to.data.frame=T)

server <- function(input, output){
  
  output$irisplot <- renderPlot({
    ggplot(iris, aes(x=Sepal.Length, y=Sepal.Width)) + geom_point() +  
      geom_smooth(method="loess", formula=y~x, se=FALSE, span=input$span_adj) + theme_bw()
  })
  
  output$span_val <- renderText({
    paste0("Span = ", input$span_adj)
  })
  
  output$data_table <- renderDataTable({
    iris
  })
  
  output$summary_var <- renderPrint({
    summary(iris[, c("Sepal.Length", "Sepal.Width")])
  })
  
  scs_data <- reactive({
    scs$mathpre2 <- scs$mathpre + rnorm(nrow(scs), mean = 0, sd = input$sd) # add noise
    scs
  })
  
  scs_data2 <- reactive({
    scs$mathpre2 <- scs$mathpre + rnorm(nrow(scs), mean = 0, sd = input$sd2) # add noise
    scs
  })
  
  output$scsplot <- renderPlot({
    ggplot(scs_data(), aes(x=mars, y=mathpre2)) + geom_point(alpha=0.3) + geom_smooth(method="loess", formula=y~x, se=FALSE, span=input$span)  + theme_bw() + ylim(-1, 20) + xlim(22, 128)
  })
  
  output$scsplot2 <- renderPlot({
    ggplot(scs_data2(), aes(x=mars, y=mathpre2)) + geom_point(alpha=0.3) + geom_smooth(method="loess", formula=y~x, se=FALSE, span=input$span2, col="red")  + theme_bw() + ylim(-1, 20) + xlim(22, 128)
  })
}